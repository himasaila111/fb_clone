import './style.css';
import Topbar from '../../components/topBar/index';
import Sidebar from '../../components/sideBar/index';
import Feed from "../../components/feed/index";
import Rightbar from "../../components/rightBar/index";

export default function Home() {
    return (
        <div>
            <Topbar />
            <div className="homeContainer">
                <Sidebar />
                <Feed />
                <Rightbar />
            </div>
        </div>
    )
}