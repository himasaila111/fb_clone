import Home from '../src/pages/home/index'
function App() {
  return (
    <Home/>
  );
}

export default App;
