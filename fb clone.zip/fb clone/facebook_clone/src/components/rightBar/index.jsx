import './rightBar.css';

export default function Rightbar() {
  return (
    <div className='rightBarContainer'>
      rightbar
    </div>
  )
}
