import React from 'react';
import './topBar.css';
import SearchIcon from '@mui/icons-material/Search';
import PersonIcon from '@mui/icons-material/Person';
import ForumIcon from '@mui/icons-material/Forum';
import NotificationsIcon from '@mui/icons-material/Notifications';
import profile from '../../images/girl.jpg';

export default function Topbar() {
    return (
        <div className="topBarContainer">
            <div className="topBarLeft">
                <span className="logo">FBook</span>
            </div>
            <div className="topBarCenter">
                <div className="searchBar">
                    <SearchIcon className="searchIcon" />
                    <input placeholder="search for friend, post or video" className="searchInput" />
                </div>
            </div>
            <div className="topBarRight">
                <div className="topBarLinks">
                    <span className="topbarLink">Homepage</span>
                    <span className="topbarLink">Timeline</span>
                </div>
                <div className="topBarIcons">
                    <div className="topBarIconItem">
                        <PersonIcon />
                        <span className="topBarIconBadge">2</span>
                    </div>
                    <div className="topBarIconItem">
                        <ForumIcon />
                        <span className="topBarIconBadge">3</span>
                    </div>
                    <div className="topBarIconItem">
                        <NotificationsIcon />
                        <span className="topBarIconBadge">4</span>
                    </div>
                </div>
                <img src={profile} alt="" className="topbarImg"/>
            </div>
        </div>
    )
}