import './feed.css';

export default function Feed() {
  return (
    <div className='feedContainer'>
      feed
    </div>
  )
}
